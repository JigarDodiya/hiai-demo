package com.example.android_10_std.Screen.Home_Screen.View;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.BlurMaskFilter;
import android.graphics.Shader;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.android_10_std.R;
import com.example.android_10_std.Utils.StickerView;

public class Home_Activity extends AppCompatActivity {

    private TextView hello;
    private Button one,two,three,four;
    private static FrameLayout id_imageFrame;
    private static StickerView mCurrentView;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        hello=findViewById(R.id.hello);
        one=findViewById(R.id.one);
        two=findViewById(R.id.two);
        id_imageFrame=findViewById(R.id.id_imageFrame);
        three=findViewById(R.id.three);
        four=findViewById(R.id.four);

        id_imageFrame.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(mCurrentView!=null)
                {
                    mCurrentView.setInEdit(false);
                }
                return false;
            }
        });


        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hello.setLayerType(View.LAYER_TYPE_SOFTWARE,null);
                hello.getPaint().setMaskFilter(null);
            }
        });

        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                applyBlurMaskFilter(hello, BlurMaskFilter.Blur.INNER);


            }
        });

        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                applyBlurMaskFilter(hello, BlurMaskFilter.Blur.OUTER);


            }
        });

        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sticker_Create();
//                applyBlurMaskFilter(hello, BlurMaskFilter.Blur.SOLID);
//                    sticker_Create(10);

            }
        });


        Bitmap bitmap= BitmapFactory.decodeResource(getResources(),R.drawable.img);
        Shader shader= new BitmapShader(bitmap,Shader.TileMode.REPEAT,Shader.TileMode.REPEAT);
        hello.getPaint().setShader(shader);
    }
    protected void applyBlurMaskFilter(TextView tv, BlurMaskFilter.Blur style){
        float radius = tv.getTextSize()/10;
        BlurMaskFilter filter = new BlurMaskFilter(radius,style);
        tv.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        tv.getPaint().setMaskFilter(filter);
    }

    public void sticker_Create() {
        StickerView stickerView = new StickerView(Home_Activity.this);
        stickerView.setImageResource(R.drawable.dice);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
        id_imageFrame.addView(stickerView, layoutParams);
        setCurrentEdit(stickerView);
        stickerView.setOperationListener(new StickerView.OperationListener() {
            @Override
            public void onDeleteClick() {
                id_imageFrame.removeView(stickerView);
            }

            @Override
            public void onEdit(StickerView stickerView) {
                mCurrentView.setInEdit(false);
                mCurrentView = stickerView;
                mCurrentView.setInEdit(true);
            }

            @Override
            public void onTop(StickerView stickerView) {

            }
        });
    }
//
    private void setCurrentEdit(StickerView stickerView) {
        if (mCurrentView != null) {
            mCurrentView.setInEdit(false);
        }
        mCurrentView = stickerView;
        stickerView.setInEdit(true);
    }
}